CCNP ENARSI
Curso: DMVPN (Dynamic Multipoint VPN)
Laboratorio: Configuración DMVPN Phase 1 
Firmware: Routers  -> c7200-advipservicesk9-mz.152-4.S5.bin
Autor: José Tomás López